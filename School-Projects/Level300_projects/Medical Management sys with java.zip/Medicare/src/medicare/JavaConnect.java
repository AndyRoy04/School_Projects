/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package medicare;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author djeut
 */
public class JavaConnect {
    public static Connection connectDb(){
        Connection connect=null;
    try{
        Class.forName("com.mysql.cj.jdbc.Driver");
        connect=DriverManager.getConnection("jdbc:mysql://localhost:3306/medicare?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "Djeutio2004@");
        
        return connect;
    }
    catch(HeadlessException | ClassNotFoundException | SQLException e){
        JOptionPane.showMessageDialog(null, e);
    }
    return null;
    }
   
} 